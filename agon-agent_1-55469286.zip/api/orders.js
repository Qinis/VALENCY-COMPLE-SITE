import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const verifyAdmin = async () => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) throw new Error('Unauthorized');
    const { data: { user }, error } = await supabase.auth.getUser(token);
    if (error || !user) throw new Error('Invalid token');
    return user;
  };

  try {
    if (req.method === 'GET') {
      await verifyAdmin();
      const { data, error } = await supabase.from('orders').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { customer_name, email, address, phone, items, total } = req.body;
      if (!customer_name || !email || !address || !phone || !items || !total) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({ customer_name, email, address, phone, items, total })
        .select()
        .single();
      if (orderError) throw orderError;

      // Reduce stock
      for (const item of items) {
        const { data: product } = await supabase.from('products').select('stock').eq('id', item.product_id).single();
        if (product && product.stock) {
          const newStock = { ...product.stock, [item.size]: Math.max(0, (product.stock[item.size] || 0) - item.quantity) };
          await supabase.from('products').update({ stock: newStock }).eq('id', item.product_id);
        }
      }

      return res.status(201).json(order);
    }

    if (req.method === 'PUT') {
      await verifyAdmin();
      const { id, status } = req.body;
      if (!id || !status) return res.status(400).json({ error: 'Missing id or status' });
      const { data, error } = await supabase.from('orders').update({ status }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Orders API error:', err);
    const status = err.message === 'Unauthorized' || err.message === 'Invalid token' ? 401 : 500;
    res.status(status).json({ error: err.message });
  }
}
