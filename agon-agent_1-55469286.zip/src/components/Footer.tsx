import { Link } from 'react-router-dom';
import { Instagram, Twitter, Youtube, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="md:col-span-1">
            <Link to="/" className="text-3xl font-black tracking-tighter text-white uppercase">
              Valency
            </Link>
            <p className="mt-4 text-sm text-white/50 leading-relaxed">
              Premium streetwear for the bold. Designed for those who set trends, not follow them.
            </p>
            <div className="flex gap-4 mt-6">
              {[Instagram, Twitter, Youtube, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center text-white/60 hover:bg-red-600 hover:text-white transition-all"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-4">Shop</h4>
            <ul className="space-y-3 text-sm text-white/50">
              {['New Arrivals', 'Hoodies', 'T-Shirts', 'Jackets', 'Accessories'].map((item) => (
                <li key={item}>
                  <Link to="/shop" className="hover:text-white transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-4">Support</h4>
            <ul className="space-y-3 text-sm text-white/50">
              {['FAQ', 'Shipping', 'Returns', 'Size Guide', 'Contact'].map((item) => (
                <li key={item}>
                  <Link to="/shop" className="hover:text-white transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-4">Legal</h4>
            <ul className="space-y-3 text-sm text-white/50">
              {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map((item) => (
                <li key={item}>
                  <Link to="/" className="hover:text-white transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/40">
            © {new Date().getFullYear()} Valency. All rights reserved.
          </p>
          <p className="text-xs text-white/40">Designed for the streets. Built for the hype.</p>
        </div>
      </div>
    </footer>
  );
}
