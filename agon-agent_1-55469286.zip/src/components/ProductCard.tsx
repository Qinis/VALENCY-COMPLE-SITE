import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingBag, Eye } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import type { Product } from '../types';

interface ProductCardProps {
  product: Product;
  wishlisted?: boolean;
  onToggleWishlist?: () => void;
  onQuickView?: () => void;
  index?: number;
}

export default function ProductCard({
  product,
  wishlisted = false,
  onToggleWishlist,
  onQuickView,
  index = 0,
}: ProductCardProps) {
  const { addItem } = useCart();
  const [imageLoaded, setImageLoaded] = useState(false);

  const defaultSize = product.sizes[0];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      className="group relative bg-neutral-950 border border-white/5 overflow-hidden"
    >
      <Link to={`/product/${product.slug}`} className="block relative aspect-[3/4] overflow-hidden bg-neutral-900">
        {!imageLoaded && (
          <div className="absolute inset-0 bg-neutral-900 animate-pulse" />
        )}
        <img
          src={product.images[0]}
          alt={product.name}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {product.new_arrival && (
          <span className="absolute top-3 left-3 bg-red-600 text-white text-[10px] font-bold uppercase tracking-widest px-2 py-1">
            New
          </span>
        )}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
          <button
            onClick={(e) => {
              e.preventDefault();
              onQuickView?.();
            }}
            className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors"
            aria-label="Quick view"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => {
              e.preventDefault();
              addItem(product, defaultSize, 1);
            }}
            className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors"
            aria-label="Add to cart"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => {
              e.preventDefault();
              onToggleWishlist?.();
            }}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              wishlisted ? 'bg-red-600 text-white' : 'bg-white text-black hover:bg-red-500 hover:text-white'
            }`}
            aria-label="Wishlist"
          >
            <Heart className={`w-4 h-4 ${wishlisted ? 'fill-current' : ''}`} />
          </button>
        </div>
      </Link>
      <div className="p-4">
        <p className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-1">
          {product.category}
        </p>
        <Link to={`/product/${product.slug}`}>
          <h3 className="text-white font-bold text-sm md:text-base truncate hover:text-red-500 transition-colors">
            {product.name}
          </h3>
        </Link>
        <p className="mt-2 text-white font-bold">${product.price.toFixed(2)}</p>
      </div>
    </motion.div>
  );
}
