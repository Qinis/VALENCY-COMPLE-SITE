import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import SizeSelector from './SizeSelector';
import type { Product } from '../types';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function QuickViewModal({ product, isOpen, onClose }: QuickViewModalProps) {
  const { addItem } = useCart();
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const handleAdd = () => {
    if (!selectedSize) return;
    addItem(product, selectedSize, quantity);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-neutral-950 w-full max-w-4xl max-h-[90vh] overflow-y-auto border border-white/10"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 text-white flex items-center justify-center hover:bg-red-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="grid md:grid-cols-2 gap-0">
              <div className="aspect-square md:aspect-auto bg-neutral-900">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6 md:p-10 flex flex-col justify-center">
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-2">
                  {product.category}
                </p>
                <h2 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tighter mb-2">
                  {product.name}
                </h2>
                <p className="text-2xl font-bold text-white mb-6">${product.price.toFixed(2)}</p>
                <p className="text-white/60 text-sm leading-relaxed mb-8">{product.description}</p>

                <SizeSelector
                  sizes={product.sizes}
                  stock={product.stock}
                  selected={selectedSize}
                  onSelect={setSelectedSize}
                />

                <div className="flex items-center gap-4 mt-6 mb-8">
                  <div className="flex items-center border border-white/10">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      className="px-3 py-2 text-white/60 hover:text-white"
                    >
                      -
                    </button>
                    <span className="px-3 text-white font-bold min-w-[40px] text-center">{quantity}</span>
                    <button
                      onClick={() => setQuantity((q) => q + 1)}
                      className="px-3 py-2 text-white/60 hover:text-white"
                    >
                      +
                    </button>
                  </div>
                  <button
                    onClick={handleAdd}
                    disabled={!selectedSize}
                    className="flex-1 bg-white text-black py-3 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  >
                    Add to Cart
                  </button>
                </div>

                <Link
                  to={`/product/${product.slug}`}
                  onClick={onClose}
                  className="text-white/60 text-sm font-bold uppercase tracking-widest hover:text-white transition-colors"
                >
                  View Full Details →
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
