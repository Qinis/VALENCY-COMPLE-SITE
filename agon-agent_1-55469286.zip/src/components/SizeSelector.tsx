interface SizeSelectorProps {
  sizes: string[];
  stock: Record<string, number>;
  selected: string;
  onSelect: (size: string) => void;
}

export default function SizeSelector({ sizes, stock, selected, onSelect }: SizeSelectorProps) {
  return (
    <div>
      <p className="text-xs font-bold uppercase tracking-widest text-white/60 mb-3">Select Size</p>
      <div className="flex flex-wrap gap-2">
        {sizes.map((size) => {
          const inStock = (stock[size] ?? 0) > 0;
          return (
            <button
              key={size}
              onClick={() => inStock && onSelect(size)}
              disabled={!inStock}
              className={`min-w-[48px] px-3 py-2 text-sm font-bold border transition-all ${
                selected === size
                  ? 'bg-white text-black border-white'
                  : inStock
                  ? 'border-white/20 text-white hover:border-white'
                  : 'border-white/10 text-white/30 cursor-not-allowed line-through'
              }`}
            >
              {size}
            </button>
          );
        })}
      </div>
    </div>
  );
}
