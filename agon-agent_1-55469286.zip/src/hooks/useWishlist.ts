import { useEffect, useState } from 'react';
import type { Product } from '../types';

const WISHLIST_KEY = 'valency_wishlist';

export function useWishlist() {
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(WISHLIST_KEY);
      if (saved) setWishlist(JSON.parse(saved));
    } catch {
      setWishlist([]);
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist));
  }, [wishlist, loaded]);

  const toggle = (product: Product) => {
    setWishlist((prev) =>
      prev.includes(product.id) ? prev.filter((id) => id !== product.id) : [...prev, product.id]
    );
  };

  const isWishlisted = (product: Product) => wishlist.includes(product.id);

  return { wishlist, toggle, isWishlisted };
}
