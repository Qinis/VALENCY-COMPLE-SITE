import { useEffect, useState } from 'react';
import type { Product } from '../types';

interface UseProductsOptions {
  category?: string;
  featured?: boolean;
  newArrival?: boolean;
  search?: string;
  slug?: string;
}

export function useProducts(options: UseProductsOptions = {}) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (options.category && options.category !== 'all') params.set('category', options.category);
      if (options.featured) params.set('featured', 'true');
      if (options.newArrival) params.set('new_arrival', 'true');
      if (options.search) params.set('search', options.search);
      if (options.slug) params.set('slug', options.slug);

      const res = await fetch(`/api/products?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to load products');
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [options.category, options.featured, options.newArrival, options.search, options.slug]);

  return { products, loading, error, refetch: fetchProducts };
}
