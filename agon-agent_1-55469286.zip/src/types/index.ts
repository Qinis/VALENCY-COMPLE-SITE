export interface Product {
  id: number;
  name: string;
  slug: string;
  price: number;
  category: string;
  sizes: string[];
  stock: Record<string, number>;
  images: string[];
  description: string;
  featured: boolean;
  new_arrival: boolean;
  created_at: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
}

export interface CartItem {
  product: Product;
  size: string;
  quantity: number;
}

export interface OrderItem {
  product_id: number;
  name: string;
  size: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: number;
  customer_name: string;
  email: string;
  address: string;
  phone: string;
  items: OrderItem[];
  total: number;
  status: string;
  created_at: string;
}

export interface Review {
  id: number;
  product_id: number;
  name: string;
  rating: number;
  comment: string;
  created_at: string;
}
