import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, CreditCard, Loader2 } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

export default function Checkout() {
  const { items, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'form' | 'processing' | 'success'>('form');
  const [form, setForm] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    zip: '',
    phone: '',
  });

  const shipping = subtotal > 150 ? 0 : 12;
  const total = subtotal + shipping;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('processing');

    const orderItems = items.map((item) => ({
      product_id: item.product.id,
      name: item.product.name,
      size: item.size,
      quantity: item.quantity,
      price: item.product.price,
    }));

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_name: form.name,
          email: form.email,
          address: `${form.address}, ${form.city}, ${form.zip}`,
          phone: form.phone,
          items: orderItems,
          total,
        }),
      });
      if (!res.ok) throw new Error('Order failed');
      setStatus('success');
      clearCart();
    } catch {
      setStatus('form');
      alert('Something went wrong. Please try again.');
    }
  };

  if (items.length === 0 && status !== 'success') {
    return (
      <div className="bg-black min-h-screen pt-24 px-4 text-center">
        <p className="text-white/50">Your cart is empty.</p>
        <button
          onClick={() => navigate('/shop')}
          className="mt-4 text-red-500 font-bold uppercase tracking-widest"
        >
          Go to Shop
        </button>
      </div>
    );
  }

  if (status === 'success') {
    return (
      <div className="bg-black min-h-screen pt-24 md:pt-32 px-4 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center max-w-lg"
        >
          <div className="w-20 h-20 rounded-full bg-green-600 flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tighter mb-4">
            Order Confirmed
          </h1>
          <p className="text-white/50 mb-8">
            Thank you, {form.name}. Your order has been placed. You will receive a confirmation email at{' '}
            {form.email}.
          </p>
          <button
            onClick={() => navigate('/shop')}
            className="bg-white text-black px-8 py-4 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-colors"
          >
            Continue Shopping
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="bg-black min-h-screen pt-24 md:pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate('/cart')}
          className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm font-bold uppercase tracking-widest mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Cart
        </button>

        <h1 className="text-4xl md:text-6xl font-black text-white uppercase tracking-tighter mb-10">
          Checkout
        </h1>

        <div className="grid lg:grid-cols-3 gap-10">
          <form onSubmit={handleSubmit} className="lg:col-span-2 space-y-6">
            <div className="bg-neutral-950 border border-white/10 p-6">
              <h2 className="text-white font-black uppercase tracking-tighter text-lg mb-6">
                Contact & Shipping
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Full Name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
                <input
                  type="email"
                  placeholder="Email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
                <input
                  type="tel"
                  placeholder="Phone"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
                <input
                  type="text"
                  placeholder="Address"
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600 md:col-span-2"
                />
                <input
                  type="text"
                  placeholder="City"
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
                <input
                  type="text"
                  placeholder="ZIP / Postal"
                  value={form.zip}
                  onChange={(e) => setForm({ ...form, zip: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
              </div>
            </div>

            <div className="bg-neutral-950 border border-white/10 p-6">
              <h2 className="text-white font-black uppercase tracking-tighter text-lg mb-6 flex items-center gap-2">
                <CreditCard className="w-5 h-5" /> Payment
              </h2>
              <p className="text-white/40 text-sm">
                This is a demo store. No real payment will be processed. Click "Place Order" to
                complete your purchase.
              </p>
            </div>
          </form>

          <div className="lg:col-span-1">
            <div className="bg-neutral-950 border border-white/10 p-6 sticky top-28">
              <h2 className="text-white font-black uppercase tracking-tighter text-lg mb-6">
                Order Summary
              </h2>
              <div className="space-y-4 max-h-64 overflow-y-auto mb-6">
                {items.map((item) => (
                  <div key={`${item.product.id}-${item.size}`} className="flex gap-3">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-14 h-14 object-cover bg-neutral-900"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-bold truncate">{item.product.name}</p>
                      <p className="text-white/40 text-xs">
                        {item.size} x {item.quantity}
                      </p>
                    </div>
                    <p className="text-white text-sm font-bold">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>
              <div className="border-t border-white/10 pt-4 space-y-2 text-sm">
                <div className="flex justify-between text-white/60">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-white/60">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-white font-bold text-lg pt-2">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
              <button
                onClick={handleSubmit}
                disabled={status === 'processing'}
                className="w-full bg-white text-black py-4 mt-6 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
              >
                {status === 'processing' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Processing
                  </>
                ) : (
                  'Place Order'
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
