import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

export default function Cart() {
  const { items, removeItem, updateQuantity, subtotal, clearCart } = useCart();
  const shipping = subtotal > 150 ? 0 : 12;
  const total = subtotal + shipping;

  return (
    <div className="bg-black min-h-screen pt-24 md:pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl md:text-6xl font-black text-white uppercase tracking-tighter mb-10">
          Shopping Cart
        </h1>

        {items.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <ShoppingBag className="w-20 h-20 text-white/10 mx-auto mb-6" />
            <p className="text-white/50 text-lg mb-6">Your cart is empty.</p>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 bg-white text-black px-8 py-4 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-colors"
            >
              Start Shopping <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2 space-y-6">
              {items.map((item) => (
                <motion.div
                  key={`${item.product.id}-${item.size}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex gap-4 md:gap-6 bg-neutral-950 border border-white/5 p-4"
                >
                  <Link to={`/product/${item.product.slug}`}>
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-24 h-32 md:w-32 md:h-40 object-cover bg-neutral-900"
                    />
                  </Link>
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <Link to={`/product/${item.product.slug}`}>
                        <h3 className="text-white font-bold text-lg hover:text-red-500 transition-colors">
                          {item.product.name}
                        </h3>
                      </Link>
                      <p className="text-white/40 text-sm mt-1">Size: {item.size}</p>
                    </div>
                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center border border-white/10">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.size, item.quantity - 1)}
                          className="px-3 py-2 text-white/60 hover:text-white"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-3 text-white font-bold text-sm">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.size, item.quantity + 1)}
                          className="px-3 py-2 text-white/60 hover:text-white"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <div className="flex items-center gap-4">
                        <p className="text-white font-bold text-lg">
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </p>
                        <button
                          onClick={() => removeItem(item.product.id, item.size)}
                          className="text-white/30 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
              <button
                onClick={clearCart}
                className="text-white/40 text-xs uppercase tracking-widest hover:text-white transition-colors"
              >
                Clear Cart
              </button>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-neutral-950 border border-white/10 p-6 sticky top-28">
                <h2 className="text-white font-black uppercase tracking-tighter text-xl mb-6">
                  Order Summary
                </h2>
                <div className="space-y-4 text-sm">
                  <div className="flex justify-between text-white/60">
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-white/60">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                  </div>
                  <div className="border-t border-white/10 pt-4 flex justify-between text-white font-bold text-lg">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
                {subtotal < 150 && (
                  <p className="text-white/40 text-xs mt-4">
                    Add ${(150 - subtotal).toFixed(2)} more for free shipping.
                  </p>
                )}
                <Link
                  to="/checkout"
                  className="block w-full bg-white text-black text-center py-4 mt-6 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-colors"
                >
                  Proceed to Checkout
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
