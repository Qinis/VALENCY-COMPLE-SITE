import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { useProducts } from '../hooks/useProducts';
import ProductCard from '../components/ProductCard';
import Newsletter from '../components/Newsletter';
import { useWishlist } from '../hooks/useWishlist';
import QuickViewModal from '../components/QuickViewModal';
import type { Product } from '../types';

const lifestyleImages = [
  'https://images.pexels.com/photos/6777968/pexels-photo-6777968.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
  'https://images.pexels.com/photos/6311475/pexels-photo-6311475.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
];

export default function Home() {
  const { products: featured, loading: featuredLoading } = useProducts({ featured: true });
  const { products: newArrivals, loading: arrivalsLoading } = useProducts({ newArrival: true });
  const { toggle, isWishlisted } = useWishlist();
  const [quickView, setQuickView] = useState<Product | null>(null);
  const [showVideo, setShowVideo] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowVideo(true), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="bg-black min-h-screen">
      {/* Hero */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {showVideo && (
          <div
            className="absolute inset-0 bg-cover bg-center opacity-40"
            style={{
              backgroundImage:
                'url(https://images.pexels.com/photos/6777968/pexels-photo-6777968.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080)',
            }}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/30 to-black" />
        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-red-500 font-bold uppercase tracking-[0.3em] text-sm mb-4"
          >
            New Collection Out Now
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-6xl sm:text-8xl md:text-9xl font-black text-white uppercase tracking-tighter mb-6"
          >
            Valency
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto mb-10"
          >
            Premium streetwear engineered for the streets. Bold fits, raw energy, zero compromise.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 bg-white text-black px-8 py-4 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-colors"
            >
              Shop Now <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>
        </div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/40 text-xs uppercase tracking-widest animate-bounce"
        >
          Scroll
        </motion.div>
      </section>

      {/* Featured */}
      <section className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex items-end justify-between mb-12">
          <div>
            <p className="text-red-500 font-bold uppercase tracking-widest text-xs mb-2">Curated</p>
            <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tighter">
              Featured Drops
            </h2>
          </div>
          <Link
            to="/shop"
            className="hidden md:flex items-center gap-1 text-white/60 hover:text-white text-sm font-bold uppercase tracking-widest transition-colors"
          >
            View All <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {featuredLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="aspect-[3/4] bg-neutral-900 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {featured.slice(0, 4).map((product, i) => (
              <ProductCard
                key={product.id}
                product={product}
                index={i}
                wishlisted={isWishlisted(product)}
                onToggleWishlist={() => toggle(product)}
                onQuickView={() => setQuickView(product)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Lifestyle banner */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-4">
          {lifestyleImages.map((src, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative aspect-[16/10] overflow-hidden group"
            >
              <img
                src={src}
                alt="Lifestyle"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors" />
              <div className="absolute bottom-6 left-6 md:bottom-10 md:left-10">
                <p className="text-white/70 text-xs uppercase tracking-[0.3em] mb-2">Lifestyle</p>
                <h3 className="text-2xl md:text-4xl font-black text-white uppercase tracking-tighter">
                  {i === 0 ? 'Own The Streets' : 'Rule The Night'}
                </h3>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex items-end justify-between mb-12">
          <div>
            <p className="text-red-500 font-bold uppercase tracking-widest text-xs mb-2">Fresh</p>
            <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tighter">
              New Arrivals
            </h2>
          </div>
          <Link
            to="/shop?filter=new"
            className="hidden md:flex items-center gap-1 text-white/60 hover:text-white text-sm font-bold uppercase tracking-widest transition-colors"
          >
            View All <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {arrivalsLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="aspect-[3/4] bg-neutral-900 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {newArrivals.slice(0, 4).map((product, i) => (
              <ProductCard
                key={product.id}
                product={product}
                index={i}
                wishlisted={isWishlisted(product)}
                onToggleWishlist={() => toggle(product)}
                onQuickView={() => setQuickView(product)}
              />
            ))}
          </div>
        )}
      </section>

      <Newsletter />
      <QuickViewModal product={quickView} isOpen={!!quickView} onClose={() => setQuickView(null)} />
    </div>
  );
}
