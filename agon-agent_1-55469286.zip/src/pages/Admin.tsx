import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Trash2, Edit2, LogOut, Package, ShoppingBag, Save, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useProducts } from '../hooks/useProducts';
import type { Product, Order } from '../types';

const defaultProduct = {
  name: '',
  slug: '',
  price: 0,
  category: 'Hoodies',
  sizes: ['S', 'M', 'L', 'XL'],
  stock: { S: 10, M: 10, L: 10, XL: 10 },
  images: [''],
  description: '',
  featured: false,
  new_arrival: true,
};

export default function Admin() {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const { products, loading: productsLoading, refetch } = useProducts();
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'products' | 'orders'>('products');
  const [form, setForm] = useState<Partial<Product>>(defaultProduct);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    const session = await import('../lib/supabase').then((m) => m.default.auth.getSession());
    const token = session.data.session?.access_token;
    const res = await fetch('/api/orders', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) setOrders(await res.json());
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return null;

  const getToken = async () => {
    const session = await import('../lib/supabase').then((m) => m.default.auth.getSession());
    return session.data.session?.access_token || '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setMessage('');
    const token = await getToken();
    const method = editingId ? 'PUT' : 'POST';
    const body = editingId ? { ...form, id: editingId } : form;

    const res = await fetch('/api/products', {
      method,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });

    if (res.ok) {
      setMessage(editingId ? 'Product updated' : 'Product added');
      setForm(defaultProduct);
      setEditingId(null);
      refetch();
    } else {
      const err = await res.json();
      setMessage(err.error || 'Failed to save product');
    }
    setSubmitting(false);
  };

  const handleEdit = (product: Product) => {
    setForm(product);
    setEditingId(product.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this product?')) return;
    const token = await getToken();
    const res = await fetch('/api/products', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ id }),
    });
    if (res.ok) {
      setMessage('Product deleted');
      refetch();
    }
  };

  const updateStock = async (product: Product, size: string, value: number) => {
    const token = await getToken();
    const newStock = { ...product.stock, [size]: Math.max(0, value) };
    const res = await fetch('/api/products', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ id: product.id, stock: newStock }),
    });
    if (res.ok) refetch();
  };

  const updateOrderStatus = async (id: number, status: string) => {
    const token = await getToken();
    await fetch('/api/orders', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ id, status }),
    });
    fetchOrders();
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };

  const categories = ['Hoodies', 'T-Shirts', 'Jackets', 'Pants', 'Accessories'];

  return (
    <div className="min-h-screen bg-black pt-24 md:pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10">
          <div>
            <h1 className="text-4xl md:text-5xl font-black text-white uppercase tracking-tighter">
              Admin
            </h1>
            <p className="text-white/50 mt-1">{user.email}</p>
          </div>
          <button
            onClick={handleLogout}
            className="inline-flex items-center gap-2 bg-white/5 text-white px-5 py-3 font-bold uppercase tracking-widest hover:bg-red-600 transition-colors"
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>

        <div className="flex gap-6 border-b border-white/10 mb-10">
          <button
            onClick={() => setActiveTab('products')}
            className={`pb-3 text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-colors ${
              activeTab === 'products' ? 'text-red-500 border-b-2 border-red-500' : 'text-white/50'
            }`}
          >
            <Package className="w-4 h-4" /> Products
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`pb-3 text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-colors ${
              activeTab === 'orders' ? 'text-red-500 border-b-2 border-red-500' : 'text-white/50'
            }`}
          >
            <ShoppingBag className="w-4 h-4" /> Orders
          </button>
        </div>

        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-white/5 border border-white/10 text-white text-sm"
          >
            {message}
          </motion.div>
        )}

        {activeTab === 'products' ? (
          <div className="space-y-10">
            <form
              onSubmit={handleSubmit}
              className="bg-neutral-950 border border-white/10 p-6 md:p-8"
            >
              <h2 className="text-white font-black uppercase tracking-tighter text-xl mb-6 flex items-center gap-2">
                {editingId ? <Edit2 className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                {editingId ? 'Edit Product' : 'Add Product'}
              </h2>
              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <input
                  type="text"
                  placeholder="Product Name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
                <input
                  type="text"
                  placeholder="Slug (e.g. valency-hoodie-black)"
                  value={form.slug}
                  onChange={(e) => setForm({ ...form, slug: e.target.value })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
                <input
                  type="number"
                  placeholder="Price"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600"
                />
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="bg-black border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-red-600"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  placeholder="Image URLs (comma separated)"
                  value={form.images?.join(', ')}
                  onChange={(e) =>
                    setForm({ ...form, images: e.target.value.split(',').map((s) => s.trim()) })
                  }
                  required
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600 md:col-span-2"
                />
                <textarea
                  placeholder="Description"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={3}
                  className="bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-600 md:col-span-2"
                />
                <label className="flex items-center gap-2 text-white/60 text-sm">
                  <input
                    type="checkbox"
                    checked={form.featured}
                    onChange={(e) => setForm({ ...form, featured: e.target.checked })}
                    className="accent-red-600"
                  />
                  Featured
                </label>
                <label className="flex items-center gap-2 text-white/60 text-sm">
                  <input
                    type="checkbox"
                    checked={form.new_arrival}
                    onChange={(e) => setForm({ ...form, new_arrival: e.target.checked })}
                    className="accent-red-600"
                  />
                  New Arrival
                </label>
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-white text-black px-6 py-3 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white disabled:opacity-50 transition-colors flex items-center gap-2"
                >
                  <Save className="w-4 h-4" /> {submitting ? 'Saving...' : editingId ? 'Update' : 'Add'}
                </button>
                {editingId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingId(null);
                      setForm(defaultProduct);
                    }}
                    className="bg-white/5 text-white px-6 py-3 font-black uppercase tracking-widest hover:bg-white/10 transition-colors flex items-center gap-2"
                  >
                    <X className="w-4 h-4" /> Cancel
                  </button>
                )}
              </div>
            </form>

            {productsLoading ? (
              <div className="text-white/50">Loading products...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-white/10 text-white/40 uppercase tracking-widest text-xs">
                    <tr>
                      <th className="pb-3">Product</th>
                      <th className="pb-3">Price</th>
                      <th className="pb-3">Stock</th>
                      <th className="pb-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {products.map((product) => (
                      <tr key={product.id}>
                        <td className="py-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              className="w-12 h-12 object-cover bg-neutral-900"
                            />
                            <div>
                              <p className="text-white font-bold">{product.name}</p>
                              <p className="text-white/40 text-xs">{product.category}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 text-white">${product.price.toFixed(2)}</td>
                        <td className="py-4">
                          <div className="flex flex-wrap gap-2">
                            {product.sizes.map((size) => (
                              <div key={size} className="flex items-center gap-1">
                                <span className="text-white/40 text-xs">{size}</span>
                                <input
                                  type="number"
                                  value={product.stock[size] || 0}
                                  onChange={(e) => updateStock(product, size, Number(e.target.value))}
                                  className="w-12 bg-black border border-white/10 text-white text-xs px-1 py-1"
                                />
                              </div>
                            ))}
                          </div>
                        </td>
                        <td className="py-4">
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleEdit(product)}
                              className="p-2 text-white/60 hover:text-white transition-colors"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(product.id)}
                              className="p-2 text-white/60 hover:text-red-500 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {orders.length === 0 ? (
              <p className="text-white/50">No orders yet.</p>
            ) : (
              orders.map((order) => (
                <div key={order.id} className="bg-neutral-950 border border-white/10 p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                    <div>
                      <p className="text-white font-bold">Order #{order.id}</p>
                      <p className="text-white/40 text-sm">{order.customer_name}</p>
                      <p className="text-white/40 text-sm">{order.email}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <select
                        value={order.status}
                        onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                        className="bg-black border border-white/10 text-white text-sm px-3 py-2"
                      >
                        {['pending', 'processing', 'shipped', 'delivered', 'cancelled'].map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                      <p className="text-white font-bold">${order.total.toFixed(2)}</p>
                    </div>
                  </div>
                  <div className="border-t border-white/10 pt-4 space-y-2">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="text-white/60">
                          {item.name} — {item.size} x {item.quantity}
                        </span>
                        <span className="text-white/60">
                          ${(item.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
