import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { SlidersHorizontal, X } from 'lucide-react';
import { useProducts } from '../hooks/useProducts';
import ProductCard from '../components/ProductCard';
import { useWishlist } from '../hooks/useWishlist';
import QuickViewModal from '../components/QuickViewModal';
import type { Product } from '../types';

const priceRanges = [
  { label: 'All', min: 0, max: Infinity },
  { label: 'Under $50', min: 0, max: 50 },
  { label: '$50 - $100', min: 50, max: 100 },
  { label: '$100+', min: 100, max: Infinity },
];

const sizeOptions = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One Size'];

export default function Shop() {
  const [searchParams, setSearchParams] = useSearchParams();
  const filterParam = searchParams.get('filter');
  const initialCategory = searchParams.get('category') || 'all';

  const [category, setCategory] = useState(initialCategory);
  const [priceRange, setPriceRange] = useState(priceRanges[0]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const { products, loading } = useProducts({
    category,
    newArrival: filterParam === 'new',
  });
  const { toggle, isWishlisted } = useWishlist();
  const [quickView, setQuickView] = useState<Product | null>(null);

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const inPrice = p.price >= priceRange.min && p.price <= priceRange.max;
      const inSize =
        selectedSizes.length === 0 || selectedSizes.some((size) => p.sizes.includes(size));
      return inPrice && inSize;
    });
  }, [products, priceRange, selectedSizes]);

  const toggleSize = (size: string) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  const clearFilters = () => {
    setCategory('all');
    setPriceRange(priceRanges[0]);
    setSelectedSizes([]);
    setSearchParams({});
  };

  const FilterContent = () => (
    <div className="space-y-8">
      <div>
        <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-4">Category</h4>
        <div className="space-y-2">
          {['all', 'Hoodies', 'T-Shirts', 'Jackets', 'Pants', 'Accessories'].map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setCategory(cat);
                if (cat === 'all') {
                  const newParams = new URLSearchParams(searchParams);
                  newParams.delete('category');
                  setSearchParams(newParams);
                } else {
                  setSearchParams({ category: cat });
                }
              }}
              className={`block w-full text-left text-sm capitalize transition-colors ${
                category === cat ? 'text-red-500 font-bold' : 'text-white/50 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-4">Price</h4>
        <div className="space-y-2">
          {priceRanges.map((range) => (
            <button
              key={range.label}
              onClick={() => setPriceRange(range)}
              className={`block w-full text-left text-sm transition-colors ${
                priceRange.label === range.label ? 'text-red-500 font-bold' : 'text-white/50 hover:text-white'
              }`}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-4">Size</h4>
        <div className="flex flex-wrap gap-2">
          {sizeOptions.map((size) => (
            <button
              key={size}
              onClick={() => toggleSize(size)}
              className={`px-3 py-1 text-xs font-bold border transition-colors ${
                selectedSizes.includes(size)
                  ? 'bg-white text-black border-white'
                  : 'border-white/20 text-white/50 hover:border-white hover:text-white'
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={clearFilters}
        className="text-white/40 text-xs uppercase tracking-widest hover:text-white transition-colors"
      >
        Clear Filters
      </button>
    </div>
  );

  return (
    <div className="bg-black min-h-screen pt-24 md:pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <h1 className="text-4xl md:text-6xl font-black text-white uppercase tracking-tighter">
            Shop
          </h1>
          <p className="text-white/50 mt-2">Find your next statement piece.</p>
        </motion.div>

        <div className="flex gap-8">
          {/* Desktop filters */}
          <aside className="hidden lg:block w-64 shrink-0">
            <FilterContent />
          </aside>

          {/* Mobile filter button */}
          <button
            onClick={() => setMobileFiltersOpen(true)}
            className="lg:hidden fixed bottom-6 right-6 z-40 w-14 h-14 bg-red-600 text-white rounded-full shadow-lg flex items-center justify-center"
          >
            <SlidersHorizontal className="w-5 h-5" />
          </button>

          {/* Products grid */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <p className="text-white/40 text-sm">
                {loading ? 'Loading...' : `${filteredProducts.length} products`}
              </p>
            </div>

            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="aspect-[3/4] bg-neutral-900 animate-pulse" />
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-white/50 text-lg">No products match your filters.</p>
                <button
                  onClick={clearFilters}
                  className="mt-4 text-red-500 font-bold uppercase tracking-widest text-sm hover:underline"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                {filteredProducts.map((product, i) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    index={i}
                    wishlisted={isWishlisted(product)}
                    onToggleWishlist={() => toggle(product)}
                    onQuickView={() => setQuickView(product)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filters drawer */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            onClick={() => setMobileFiltersOpen(false)}
            className="absolute inset-0 bg-black/70"
          />
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            className="absolute top-0 left-0 h-full w-80 max-w-[80vw] bg-neutral-950 p-6 overflow-y-auto border-r border-white/10"
          >
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-white font-black uppercase tracking-tighter text-xl">Filters</h3>
              <button onClick={() => setMobileFiltersOpen(false)}>
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            <FilterContent />
          </motion.div>
        </div>
      )}

      <QuickViewModal product={quickView} isOpen={!!quickView} onClose={() => setQuickView(null)} />
    </div>
  );
}
