import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Star, ShoppingBag, Heart, Check } from 'lucide-react';
import { useProducts } from '../hooks/useProducts';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../hooks/useWishlist';
import SizeSelector from '../components/SizeSelector';
import ProductCard from '../components/ProductCard';
import type { Product, Review } from '../types';

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { products, loading } = useProducts({ slug });
  const { products: relatedProducts } = useProducts({ category: products[0]?.category });
  const { addItem } = useCart();
  const { toggle, isWishlisted } = useWishlist();

  const product = products[0];
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [reviewForm, setReviewForm] = useState({ name: '', rating: 5, comment: '' });
  const [reviewStatus, setReviewStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  useEffect(() => {
    if (product) {
      setSelectedImage(0);
      setSelectedSize('');
      setQuantity(1);
      fetchReviews();
    }
  }, [product?.id]);

  const fetchReviews = async () => {
    if (!product) return;
    const res = await fetch(`/api/reviews?product_id=${product.id}`);
    if (res.ok) setReviews(await res.json());
  };

  const handleAdd = () => {
    if (!product || !selectedSize) return;
    addItem(product, selectedSize, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) return;
    setReviewStatus('submitting');
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...reviewForm, product_id: product.id }),
    });
    if (res.ok) {
      setReviewForm({ name: '', rating: 5, comment: '' });
      setReviewStatus('success');
      fetchReviews();
      setTimeout(() => setReviewStatus('idle'), 3000);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black pt-24 flex items-center justify-center">
        <div className="w-10 h-10 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-black pt-24 px-4 text-center">
        <p className="text-white/50">Product not found.</p>
        <Link to="/shop" className="text-red-500 font-bold mt-4 inline-block">
          Back to Shop
        </Link>
      </div>
    );
  }

  const related = relatedProducts.filter((p) => p.id !== product.id).slice(0, 4);
  const averageRating = reviews.length
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  return (
    <div className="bg-black min-h-screen pt-20 md:pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm font-bold uppercase tracking-widest mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16">
          {/* Images */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="aspect-[4/5] bg-neutral-900 overflow-hidden">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(i)}
                  className={`w-20 h-20 md:w-24 md:h-24 shrink-0 overflow-hidden border-2 transition-colors ${
                    selectedImage === i ? 'border-red-600' : 'border-transparent'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </motion.div>

          {/* Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col justify-center"
          >
            <p className="text-red-500 font-bold uppercase tracking-widest text-xs mb-2">
              {product.category}
            </p>
            <h1 className="text-4xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
              {product.name}
            </h1>
            <div className="flex items-center gap-4 mb-6">
              <p className="text-2xl md:text-3xl font-bold text-white">${product.price.toFixed(2)}</p>
              {reviews.length > 0 && (
                <div className="flex items-center gap-1 text-white/60 text-sm">
                  <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                  <span>{averageRating.toFixed(1)}</span>
                  <span>({reviews.length})</span>
                </div>
              )}
            </div>
            <p className="text-white/60 leading-relaxed mb-8">{product.description}</p>

            <SizeSelector
              sizes={product.sizes}
              stock={product.stock}
              selected={selectedSize}
              onSelect={setSelectedSize}
            />

            <div className="flex items-center gap-4 mt-8">
              <div className="flex items-center border border-white/10">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-4 py-3 text-white/60 hover:text-white font-bold"
                >
                  -
                </button>
                <span className="px-4 text-white font-bold min-w-[48px] text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="px-4 py-3 text-white/60 hover:text-white font-bold"
                >
                  +
                </button>
              </div>
              <button
                onClick={handleAdd}
                disabled={!selectedSize}
                className={`flex-1 py-3 px-6 font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${
                  added
                    ? 'bg-green-600 text-white'
                    : 'bg-white text-black hover:bg-red-600 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed'
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4" /> Added
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" /> Add to Cart
                  </>
                )}
              </button>
              <button
                onClick={() => toggle(product)}
                className={`w-12 h-12 border flex items-center justify-center transition-colors ${
                  isWishlisted(product)
                    ? 'bg-red-600 border-red-600 text-white'
                    : 'border-white/10 text-white/60 hover:text-white'
                }`}
              >
                <Heart className={`w-5 h-5 ${isWishlisted(product) ? 'fill-current' : ''}`} />
              </button>
            </div>

            {!selectedSize && (
              <p className="text-white/40 text-xs mt-3">Please select a size to add to cart.</p>
            )}
          </motion.div>
        </div>

        {/* Reviews */}
        <section className="mt-20 md:mt-32 border-t border-white/10 pt-16">
          <h2 className="text-2xl md:text-4xl font-black text-white uppercase tracking-tighter mb-8">
            Reviews
          </h2>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              {reviews.length === 0 ? (
                <p className="text-white/50">No reviews yet. Be the first.</p>
              ) : (
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b border-white/10 pb-6">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-white font-bold">{review.name}</span>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < review.rating ? 'fill-yellow-500 text-yellow-500' : 'text-white/20'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-white/60 text-sm">{review.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <form onSubmit={submitReview} className="bg-neutral-950 p-6 border border-white/10">
              <h3 className="text-white font-bold uppercase tracking-widest mb-4">Write a Review</h3>
              <input
                type="text"
                placeholder="Your name"
                value={reviewForm.name}
                onChange={(e) => setReviewForm({ ...reviewForm, name: e.target.value })}
                required
                className="w-full bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 mb-4 focus:outline-none focus:border-red-600"
              />
              <select
                value={reviewForm.rating}
                onChange={(e) => setReviewForm({ ...reviewForm, rating: Number(e.target.value) })}
                className="w-full bg-black border border-white/10 px-4 py-3 text-white mb-4 focus:outline-none focus:border-red-600"
              >
                {[5, 4, 3, 2, 1].map((r) => (
                  <option key={r} value={r}>
                    {r} Stars
                  </option>
                ))}
              </select>
              <textarea
                placeholder="Your review"
                value={reviewForm.comment}
                onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                rows={4}
                className="w-full bg-black border border-white/10 px-4 py-3 text-white placeholder:text-white/30 mb-4 focus:outline-none focus:border-red-600"
              />
              <button
                type="submit"
                disabled={reviewStatus === 'submitting'}
                className="w-full bg-white text-black py-3 font-black uppercase tracking-widest hover:bg-red-600 hover:text-white disabled:opacity-50 transition-colors"
              >
                {reviewStatus === 'submitting' ? 'Submitting...' : 'Submit Review'}
              </button>
              {reviewStatus === 'success' && (
                <p className="mt-3 text-green-500 text-sm">Review submitted!</p>
              )}
            </form>
          </div>
        </section>

        {/* Related */}
        {related.length > 0 && (
          <section className="mt-20 md:mt-32">
            <h2 className="text-2xl md:text-4xl font-black text-white uppercase tracking-tighter mb-8">
              You May Also Like
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {related.map((p, i) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  index={i}
                  wishlisted={isWishlisted(p)}
                  onToggleWishlist={() => toggle(p)}
                />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
